
  # 酒店查询层级UI设计

  This is a code bundle for 酒店查询层级UI设计. The original project is available at https://www.figma.com/design/1fgnFGhZYipM9ETmOo4eTm/%E9%85%92%E5%BA%97%E6%9F%A5%E8%AF%A2%E5%B1%82%E7%BA%A7UI%E8%AE%BE%E8%AE%A1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  