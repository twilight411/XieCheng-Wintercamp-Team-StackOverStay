import React from "react";
import { motion } from "motion/react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface TabProps {
  label: string;
  active: boolean;
  onClick: () => void;
}

const Tab = ({ label, active, onClick }: TabProps) => {
  return (
    <button
      onClick={onClick}
      className={cn(
        "relative flex-1 py-3 text-sm font-medium transition-colors duration-200 cursor-pointer",
        active ? "text-blue-600" : "text-gray-600"
      )}
    >
      <div
        className={cn(
          "absolute inset-0 z-0",
          active ? "bg-white" : "bg-gray-100"
        )}
        style={{
          borderRadius: active ? "16px 16px 0 0" : "0",
          clipPath: active 
            ? "polygon(0 100%, 10% 0, 90% 0, 100% 100%)" 
            : "none"
        }}
      />
      <span className="relative z-10">{label}</span>
      {active && (
        <motion.div
          layoutId="activeTabUnderline"
          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-1 bg-blue-500 rounded-full z-20"
        />
      )}
    </button>
  );
};

// A better "Folder Tab" look using SVG or complex CSS
const SplashIcon = () => (
  <svg
    width="28"
    height="16"
    viewBox="0 0 28 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className="absolute -right-3 -bottom-1 pointer-events-none z-0"
  >
    <path
      d="M2 14C8 14 14 12 18 8C22 4 26 0 27 2C28 4 26 8 22 11C18 14 10 16 2 14Z"
      fill="url(#splash_gradient)"
      fillOpacity="0.7"
    />
    <defs>
      <linearGradient id="splash_gradient" x1="2" y1="14" x2="27" y2="2" gradientUnits="userSpaceOnUse">
        <stop stopColor="#3B82F6" />
        <stop offset="1" stopColor="#93C5FD" />
      </linearGradient>
    </defs>
  </svg>
);

export const FolderTabs = ({ 
  activeTab, 
  onChange 
}: { 
  activeTab: number; 
  onChange: (index: number) => void 
}) => {
  const isLeftGroupActive = activeTab < 2;

  const groups = [
    { items: [{ label: "国内", id: 0 }, { label: "海外", id: 1 }], groupId: 0 },
    { items: [{ label: "民宿", id: 2 }, { label: "钟点房", id: 3 }], groupId: 1 }
  ];

  return (
    <div className="relative flex w-full h-14 bg-[#F2F3F5] rounded-t-2xl overflow-hidden">
      {/* Active Folder Background */}
      <div 
        className={cn(
          "absolute top-0 bottom-0 w-1/2 bg-white transition-all duration-300 ease-in-out z-10",
          isLeftGroupActive ? "left-0" : "left-1/2"
        )}
        style={{
          clipPath: isLeftGroupActive 
            ? "polygon(0 0, 92% 0, 100% 100%, 0 100%)" 
            : "polygon(8% 0, 100% 0, 100% 100%, 0 100%)"
        }}
      />

      {/* Content Overlay */}
      <div className="relative flex w-full h-full z-20">
        {groups.map((group) => (
          <div key={group.groupId} className="flex-1 flex items-center justify-around px-2">
            {group.items.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onChange(item.id)}
                  className={cn(
                    "relative font-bold text-lg transition-colors duration-300 px-2 py-1",
                    isActive ? "text-blue-600" : "text-[#1A1A1A]"
                  )}
                >
                  <span className="relative z-10">
                    {item.label}
                    {isActive && <SplashIcon />}
                  </span>
                </button>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};
